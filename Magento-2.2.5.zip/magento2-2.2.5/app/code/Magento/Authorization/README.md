# Authorization

**Authorization** enables management of access control list roles and
rules in the application.
